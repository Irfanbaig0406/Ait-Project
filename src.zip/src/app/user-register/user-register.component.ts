import { Component} from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { ServiceService } from '../service.service';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.css']
})
export class UserRegisterComponent {

  constructor(private service:ServiceService) { }

  //ngOnInit(): void {
  //}
  /*registerForm = new FormGroup({
    email : new FormControl(''),
    city : new FormControl(''),
    state : new FormControl(''),
    postalcode : new FormControl(''),
    password : new FormControl(''),
    repeat_psw : new FormControl('')*/
  
  //onSubmit(){

    //console.log(this.registerForm.value.email);
    onSubmit(registerForm:NgForm)
    {
      console.log(registerForm);
      console.log(registerForm.value.username);
      console.log(registerForm.value.password);
    this.service.register(registerForm.value.email,registerForm.value.street,registerForm.value.city, registerForm.value.password);
    }
  }


