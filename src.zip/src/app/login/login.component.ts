import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  //constructor(private formBuilder:FormBuilder) { }
 loginForm=new FormGroup({
  username: new FormControl(''),
  password: new FormControl('')
});
onSubmit() {
  // TODO: Use EventEmitter with form value
  console.log(this.loginForm.value);
  console.log(this.loginForm.value.username);
  console.log(this.loginForm.value.password);

}
 
}