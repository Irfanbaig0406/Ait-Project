import { Injectable } from '@angular/core';
//import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(private http:HttpClientModule) { }
  login(username:any,password:any){
    console.log("hi!!!");
    console.log(username,password);
  }
   register(email:any,street:any,city:any,password:any){
    console.log("email:",email);
    console.log("street:",street);
    console.log("city:",city);
    console.log("password:",password);

   }    
  
}
